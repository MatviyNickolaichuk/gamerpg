"""Генерація пулу з 200 унікальних інгредієнтів (10 типів x 20 назв)."""

INGREDIENT_TYPES = {
    "herb": "Трава", "mineral": "Мінерал", "mushroom": "Гриб",
    "flower": "Квітка", "root": "Корінь", "berry": "Ягода",
    "scale": "Луска", "feather": "Перо", "crystal": "Кристал",
    "venom": "Отрута",
}
ORIGINS = [
    "місяця", "тіней", "вогню", "льоду", "грози", "ночі", "сонця",
    "вітру", "болота", "крові", "зорі", "пустелі", "лісу", "моря",
    "хмар", "смерті", "життя", "туману", "дракона", "гір",
]


def build_ingredients():
    """Повертає dict: id -> {id, name, type}. Всього 200 штук."""
    pool = {}
    try:
        for type_key, type_name in INGREDIENT_TYPES.items():
            for origin in ORIGINS:
                item_id = f"ing_{type_key}_{ORIGINS.index(origin):02d}"
                pool[item_id] = {"id": item_id, "name": f"{type_name} {origin}",
                                 "type": type_key}
        if len(pool) < 200:
            raise ValueError("Пул інгредієнтів менший за 200")
    except (ValueError, KeyError) as e:
        raise SystemExit(f"Помилка генерації інгредієнтів: {e}")
    return pool


INGREDIENTS = build_ingredients()
