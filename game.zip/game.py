import random

from config import *
from crafting import craft, can_craft
from endings import check_ending, show_ending
from exceptions import CraftingError, InventoryFullError
from ingredients import INGREDIENTS
from input_utils import read_int
from inventory import Inventory
from potions import POTIONS
from shop import roll_market, sell, sell_all
from ui import show_inventories, show_status, recipe_text


class GameState:
    def __init__(self):
        self.day = 1
        self.gold = START_GOLD
        self.potions = Inventory("Зілля", POTION_SLOTS, POTION_STACK)
        self.ingredients = Inventory("Інгредієнти", INGREDIENT_SLOTS, INGREDIENT_STACK)


def give_ingredients(state, amount):
    lost = 0
    for iid in random.choices(list(INGREDIENTS), k=amount):
        try:
            state.ingredients.add(iid, 1)
            print(f"  + {INGREDIENTS[iid]['name']}")
        except InventoryFullError:
            lost += 1
    if lost:
        print(f"  Інвентар інгредієнтів повний, втрачено: {lost}")


def craft_menu(state):
    try:
        names = list(POTIONS.values())
        available = [p for p in names if can_craft(p, state.ingredients)]
        if not available:
            print("  Немає рецептів, які можна зварити з поточних інгредієнтів.")
            return
        for i, p in enumerate(available, 1):
            print(f"  {i}. {p['name']} - {recipe_text(p)} (ціна {p['price']})")
        choice = read_int("Що варимо? (0 - назад): ", 0, len(available))
        if choice == 0:
            return
        craft(available[choice - 1], state.ingredients, state.potions)
        print(f"  Зварено: {available[choice - 1]['name']}")
    except (CraftingError, InventoryFullError) as e:
        print(f"  Не вийшло: {e}")


def recipes_menu():
    for p in POTIONS.values():
        print(f"  {p['name']}: {recipe_text(p)}")


def sell_phase(state):
    market = roll_market()
    print(f"\n*** Вечір. Попит на ринку: x{market} ***")
    while state.potions.slots:
        try:
            for i, (pid, c) in enumerate(state.potions.slots, 1):
                print(f"  {i}. {POTIONS[pid]['name']} x{c} - {int(POTIONS[pid]['price'] * market)} за шт.")
            print("  A. Продати все   0. Завершити продаж")
            raw = input("Вибір: ").strip().lower()
            if raw == "0":
                break
            if raw == "a":
                state.gold += sell_all(state.potions, market)
                break
            idx = int(raw)
            pid, c = state.potions.slots[idx - 1]
            amount = read_int(f"Скільки продати (1-{state.potions.count(pid)})? ", 1,
                              state.potions.count(pid))
            state.gold += sell(state.potions, pid, amount, market)
            print(f"  Золото: {state.gold}")
        except (ValueError, IndexError):
            print("  Некоректний вибір.")
        except Exception as e:  # NotEnoughItemsError та ін.
            print(f"  Помилка: {e}")


def play_day(state):
    print(f"\n######## ДЕНЬ {state.day} ########\nТи отримуєш інгредієнти:")
    give_ingredients(state, START_INGREDIENTS if state.day == 1 else DAILY_INGREDIENTS)
    while True:
        show_status(state)
        print("1. Інвентар  2. Варити  3. Рецепти  4. Закінчити день")
        choice = read_int("> ", 1, 4)
        if choice == 1:
            show_inventories(state)
        elif choice == 2:
            craft_menu(state)
        elif choice == 3:
            recipes_menu()
        else:
            break
    sell_phase(state)
    state.gold -= DAILY_COST
    print(f"Витрати на життя: -{DAILY_COST}. Золото: {state.gold}")


def run():
    state = GameState()
    print("Ти - алхімік. Назбирай", WIN_GOLD, "золота за", MAX_DAYS, "днів!")
    while True:
        try:
            play_day(state)
            ending = check_ending(state)
            if ending:
                show_ending(ending, state)
                break
            state.day += 1
        except KeyboardInterrupt:
            print("\nГру перервано гравцем.")
            break
