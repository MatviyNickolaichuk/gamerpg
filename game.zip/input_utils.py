

def read_int(prompt, low, high):
    while True:
        try:
            value = int(input(prompt).strip())
            if not low <= value <= high:
                raise ValueError
            return value
        except ValueError:
            print(f"  Введіть число від {low} до {high}.")
        except EOFError:
            print("\n  Ввід перервано, виходимо.")
            raise SystemExit(0)
