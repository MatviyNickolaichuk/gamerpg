"""Варіння зіль."""
from exceptions import CraftingError, InventoryFullError, NotEnoughItemsError
from ingredients import INGREDIENTS


def plan_ingredients(potion, ing_inv):
    """Повертає список (id, к-сть) для списання або кидає CraftingError."""
    plan = []
    totals = ing_inv.totals()
    for need_type, need in potion["recipe"].items():
        for iid, have in list(totals.items()):
            if need == 0:
                break
            if INGREDIENTS[iid]["type"] == need_type and have > 0:
                take = min(have, need)
                plan.append((iid, take))
                totals[iid] -= take
                need -= take
        if need > 0:
            raise CraftingError("Бракує інгредієнтів за рецептом")
    return plan


def can_craft(potion, ing_inv):
    try:
        plan_ingredients(potion, ing_inv)
        return True
    except CraftingError:
        return False


def craft(potion, ing_inv, potion_inv):
    """Варить 1 зілля. Кидає CraftingError / InventoryFullError."""
    try:
        plan = plan_ingredients(potion, ing_inv)
        if potion_inv.free_space_for(potion["id"]) < 1:
            raise InventoryFullError("Інвентар зілля заповнений")
        for iid, n in plan:
            ing_inv.remove(iid, n)
        potion_inv.add(potion["id"], 1)
    except NotEnoughItemsError as e:
        raise CraftingError(str(e))
