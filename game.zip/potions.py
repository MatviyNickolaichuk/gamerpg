import random
from collections import Counter

from ingredients import INGREDIENT_TYPES

EFFECTS = ["лікування", "сили", "швидкості", "невидимості", "захисту",
           "мудрості", "удачі", "стійкості", "зору", "відваги"]
GRADES = [("слабке", 1, 20), ("звичайне", 2, 40), ("міцне", 3, 70),
          ("велике", 4, 110), ("легендарне", 5, 170)]


def build_potions():
    pool = {}
    try:
        rng = random.Random(42)
        types = list(INGREDIENT_TYPES)
        for effect in EFFECTS:
            for grade, tier, price in GRADES:
                n = 2 + (tier >= 3) + (tier == 5)
                recipe = dict(Counter(rng.choice(types) for _ in range(n)))
                pid = f"pot_{effect}_{tier}"
                pool[pid] = {"id": pid, "name": f"Зілля {effect} ({grade})",
                             "price": price, "recipe": recipe}
        if len(pool) < 50:
            raise ValueError("Пул зіль менший за 50")
    except (ValueError, KeyError) as e:
        raise SystemExit(f"Помилка генерації зіль: {e}")
    return pool


POTIONS = build_potions()
