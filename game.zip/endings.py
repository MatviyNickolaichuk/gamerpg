
from config import MAX_DAYS, WIN_GOLD


def check_ending(state):
    if state.gold >= WIN_GOLD:
        return "win"
    if state.gold < 0:
        return "bankrupt"
    if state.day >= MAX_DAYS:
        return "timeout"
    return None


def show_ending(kind, state):
    texts = {
        "win": f"ПЕРЕМОГА! Ти назбирав {state.gold} золота, викупив лабораторію "
               "і став головним алхіміком королівства!",
        "bankrupt": "ПОРАЗКА. Борги задушили тебе - кредитори забрали казан і "
                    "лабораторію. Кар'єра алхіміка закінчена.",
        "timeout": f"ПОРАЗКА. Минуло {MAX_DAYS} днів, а в тебе лише {state.gold} із "
                   f"{WIN_GOLD} золота. Гільдія відібрала ліцензію.",
    }
    print("\n" + "=" * 50)
    print(texts.get(kind, "Гра завершена."))
    print("=" * 50)
