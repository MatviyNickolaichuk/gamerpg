"""Точка входу: python main.py"""
from game import run

if __name__ == "__main__":
    try:
        run()
    except SystemExit:
        pass
    except Exception as e:
        print(f"Критична помилка: {e}")
