from game import run
2
2if __name__ == "__main__":
    try:
        run()
    except SystemExit:
        pass
    except Exception as e:
        print(f"Критична помилка: {e}")
