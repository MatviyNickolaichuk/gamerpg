import random

from exceptions import NotEnoughItemsError
from potions import POTIONS


def roll_market():
    return round(random.uniform(0.8, 1.3), 2)


def sell(potion_inv, potion_id, amount, market):
    try:
        price = int(POTIONS[potion_id]["price"] * market)
        potion_inv.remove(potion_id, amount)
        return price * amount
    except KeyError:
        raise NotEnoughItemsError("Такого зілля не існує")


def sell_all(potion_inv, market):
    total = 0
    for pid, n in list(potion_inv.totals().items()):
        try:
            total += sell(potion_inv, pid, n, market)
        except NotEnoughItemsError as e:
            print(f"  Помилка продажу: {e}")
    return total
