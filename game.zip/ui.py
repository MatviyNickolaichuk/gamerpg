from ingredients import INGREDIENTS, INGREDIENT_TYPES
from potions import POTIONS


def show_inventories(state):
    try:
        print(f"\n=== Інвентар зілля ({len(state.potions.slots)}/{state.potions.max_slots} слотів) ===")
        if not state.potions.slots:
            print("  (порожньо)")
        for i, (pid, c) in enumerate(state.potions.slots, 1):
            print(f"  {i}. {POTIONS[pid]['name']} x{c}")
        print(f"\n=== Інгредієнти ({len(state.ingredients.slots)}/{state.ingredients.max_slots} слотів) ===")
        if not state.ingredients.slots:
            print("  (порожньо)")
        for i, (iid, c) in enumerate(state.ingredients.slots, 1):
            print(f"  {i}. {INGREDIENTS[iid]['name']} x{c}")
    except KeyError as e:
        print(f"Помилка: невідомий предмет {e}")


def recipe_text(potion):
    return ", ".join(f"{INGREDIENT_TYPES[t]} x{n}" for t, n in potion["recipe"].items())


def show_status(state):
    print(f"\n--- День {state.day} | Золото: {state.gold} ---")
