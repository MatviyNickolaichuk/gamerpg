from exceptions import InventoryFullError, NotEnoughItemsError


class Inventory:
    def __init__(self, name, max_slots, stack_size):
        self.name = name
        self.max_slots = max_slots
        self.stack_size = stack_size
        self.slots = []  # список [item_id, count]

    def count(self, item_id):
        return sum(c for i, c in self.slots if i == item_id)

    def totals(self):
        result = {}
        for item_id, c in self.slots:
            result[item_id] = result.get(item_id, 0) + c
        return result

    def free_space_for(self, item_id):
        space = sum(self.stack_size - c for i, c in self.slots if i == item_id)
        space += (self.max_slots - len(self.slots)) * self.stack_size
        return space

    def add(self, item_id, amount=1):
        try:
            if amount <= 0:
                raise ValueError("Кількість має бути > 0")
            if self.free_space_for(item_id) <= 0:
                raise InventoryFullError(f"{self.name}: немає місця")
            left = amount
            for slot in self.slots:
                if slot[0] == item_id and left > 0:
                    put = min(self.stack_size - slot[1], left)
                    slot[1] += put
                    left -= put
            while left > 0 and len(self.slots) < self.max_slots:
                put = min(self.stack_size, left)
                self.slots.append([item_id, put])
                left -= put
            return left
        except TypeError as e:
            raise ValueError(f"Некоректні дані: {e}")

    def remove(self, item_id, amount=1):
        if amount <= 0:
            raise ValueError("Кількість має бути > 0")
        if self.count(item_id) < amount:
            raise NotEnoughItemsError(f"{self.name}: недостатньо предметів")
        left = amount
        for slot in reversed(self.slots):
            if slot[0] == item_id and left > 0:
                take = min(slot[1], left)
                slot[1] -= take
                left -= take
        self.slots = [s for s in self.slots if s[1] > 0]
