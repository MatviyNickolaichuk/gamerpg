"""Власні винятки гри."""


class GameError(Exception):
    """Базовий виняток гри."""


class InventoryFullError(GameError):
    """В інвентарі немає місця."""


class NotEnoughItemsError(GameError):
    """Недостатньо предметів в інвентарі."""


class CraftingError(GameError):
    """Не вдалося зварити зілля."""
