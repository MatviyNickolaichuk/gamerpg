

class GameError(Exception):


class InventoryFullError(GameError):


class NotEnoughItemsError(GameError):


class CraftingError(GameError):
